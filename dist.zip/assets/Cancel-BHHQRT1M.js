import{j as e}from"./index-ChLwve22.js";const l=()=>e.jsx("div",{className:"h-lvh flex flex-row justify-center items-center w-full",children:"Payment Failed"});export{l as default};
