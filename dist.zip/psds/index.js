export const psdsList = [
  "./psds/p2.jpeg",
  "./psds/p3.jpeg",
  "./psds/p4.jpeg",
  "./psds/p5.jpeg",
  "./psds/p6.jpeg",
  "./psds/p7.jpeg",
  "./psds/p8.jpeg",
  "./psds/p9.jpeg",
  "./psds/p10.jpeg",
  "./psds/p11.jpeg",
  "./psds/p12.jpeg",
  "./psds/p13.jpeg",
];
